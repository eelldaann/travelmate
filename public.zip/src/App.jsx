import { Routes, Route, Link, Navigate } from "react-router";
import { useAdmin } from "./hooks/useAdmin";

import HomePage from "./pages/HomePage";
import ToursPage from "./pages/ToursPage";
import HowItWorksPage from "./pages/HowItWorksPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import { useLang } from "./contexts/LanguageContext.jsx";
import { useCurrency } from "./contexts/CurrencyContext";
import { useAuth } from "./contexts/AuthContext.jsx";
import ConfirmPage from "./pages/ConfirmPage.jsx";
import AdminToursPage from "./pages/AdminToursPage.jsx";
import AdminOrdersPage from "./pages/AdminOrdersPage.jsx";

export default function App() {
    return (
        <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
            <Header />
            <main className="flex-1">
                <AppRoutes />
            </main>
            <Footer />
        </div>
    );
}

function AppRoutes() {
    return (
        <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tours" element={<ToursPage />} />
            <Route path="/admin/tours" element={<AdminToursPage />} />
            <Route path="/admin/orders" element={<AdminOrdersPage />} />
            <Route path="/how-it-works" element={<HowItWorksPage />} />

            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/confirm" element={<ConfirmPage />} />

            <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

    );
}

function Header() {
    const { t, lang, setLang } = useLang();
    const { currency, setCurrency } = useCurrency();
    const { user, loading, signOut } = useAuth();
    const { isAdmin } = useAdmin();


    async function handleLogout() {
        try {
            await signOut();
        } catch (e) {
            console.error(e);
        }
    }

    return (
        <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
                <Link
                    to="/"
                    className="flex items-center gap-2 text-xl md:text-2xl font-semibold tracking-tight text-slate-900"
                >
          <span className="inline-flex size-8 items-center justify-center rounded-2xl bg-sky-500/10 border border-sky-500/40">
            <span className="text-base font-bold text-sky-600"></span>
          </span>
                </Link>

                <nav className="hidden items-center gap-6 text-base text-slate-700 md:flex">
                    <NavItem to="/" label={t("nav.home")} />
                    <NavItem to="/tours" label={t("nav.tours")} />
                    <NavItem to="/how-it-works" label={t("nav.howItWorks")} />
                    {isAdmin && (
                        <>
                            <NavItem
                                to="/admin/tours"
                                label={t("nav.admin.main")}
                            />
                        </>

                    )}

                </nav>

                <div className="flex items-center gap-3">
                    {/* Валюта */}
                    <select
                        value={currency}
                        onChange={(e) => setCurrency(e.target.value)}
                        className="cursor-pointer rounded-full border border-slate-300 bg-white px-2 py-1 text-sm text-slate-700"
                    >
                        <option value="USD">$ USD</option>
                        <option value="KZT">₸ KZT</option>
                        <option value="RUB">₽ RUB</option>
                    </select>

                    {/* Язык */}
                    <select
                        value={lang}
                        onChange={(e) => setLang(e.target.value)}
                        className="cursor-pointer rounded-full border border-slate-300 bg-white px-2 py-1 text-sm text-slate-700"
                    >
                        <option value="en">EN</option>
                        <option value="ru">RU</option>
                        <option value="kz">KZ</option>
                    </select>

                    {/* Авторизация */}
                    {!loading && (
                        <div className="flex items-center gap-2">
                            {user ? (
                                <>
                                    <span
                                        className="hidden text-sm font-medium text-sky-700 sm:inline"
                                    >
                                        {user.user_metadata?.firstName
                                            ? `${user.user_metadata.firstName}`
                                            : user.email}
                                    </span>
                                    <button
                                        type="button"
                                        onClick={handleLogout}
                                        className="cursor-pointer rounded-full border border-slate-300 px-3 py-1 text-sm font-medium text-slate-700 hover:bg-slate-100"
                                    >
                                        {t("nav.logout")}
                                    </button>
                                </>
                            ) : (
                                <>
                                    <Link
                                        to="/login"
                                        className="rounded-full border border-slate-300 px-3 py-1 text-sm font-medium text-slate-700 hover:bg-slate-100"
                                    >
                                        {t("nav.login")}
                                    </Link>
                                    <Link
                                        to="/register"
                                        className="rounded-full bg-sky-600 px-3 py-1 text-sm font-semibold text-white hover:bg-sky-500"
                                    >
                                        {t("nav.register")}
                                    </Link>
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}


function NavItem({ to, label }) {
    return (
        <Link
            to={to}
            className="text-sm text-slate-600 hover:text-sky-600 transition"
        >
            {label}
        </Link>
    );
}

function Footer() {
    const { t } = useLang();

    return (
        <footer className="border-t border-slate-200 bg-white">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 text-xs text-slate-500">
                <span>
                    © {new Date().getFullYear()} {t("footer.company")}
                </span>
                <span className="flex gap-4">
                    <a href="#" className="transition hover:text-sky-600">
                        {t("footer.terms")}
                    </a>
                    <a href="#" className="transition hover:text-sky-600">
                        {t("footer.privacy")}
                    </a>
                </span>
            </div>
        </footer>
    );
}
