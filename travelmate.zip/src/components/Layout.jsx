import { NavLink, Link } from 'react-router'

export default function Layout({ children }) {
    return (
        <>
            {children}
        </>
    )
}
