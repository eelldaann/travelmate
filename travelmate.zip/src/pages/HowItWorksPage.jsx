export default function HowItWorksPage() {
    const steps = [
        {
            num: "01",
            title: "Tell us how you travel",
            text: "You share basic info: dates, budget range, number of people and your travel style.",
        },
        {
            num: "02",
            title: "We design several routes",
            text: "We mix canyons, lakes, dunes and cities into 2–3 balanced itineraries with different pace.",
        },
        {
            num: "03",
            title: "You approve details",
            text: "You pick the option you like, we fine-tune hotels, transport and activities together.",
        },
        {
            num: "04",
            title: "We book & support",
            text: "We handle bookings, transfers and stay in touch while you travel across Kazakhstan.",
        },
    ];

    return (
        <div className="mx-auto max-w-4xl px-4 py-10 space-y-8">
            <header className="space-y-3">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-600">
                    Process
                </p>
                <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-slate-900">
                    How TravelMate works
                </h1>
                <p className="text-sm md:text-base text-slate-600">
                    This page is a visual version of your “How it works” template. Only
                    layout, no backend logic.
                </p>
            </header>

            <section className="space-y-4">
                {steps.map((step) => (
                    <article
                        key={step.num}
                        className="flex gap-4 rounded-3xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm"
                    >
                        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl bg-sky-50 border border-sky-200">
              <span className="text-xs font-semibold tracking-[0.18em] text-sky-600">
                {step.num}
              </span>
                        </div>
                        <div className="space-y-1">
                            <h2 className="text-sm md:text-base font-semibold text-slate-900">
                                {step.title}
                            </h2>
                            <p className="text-xs md:text-sm text-slate-600">{step.text}</p>
                        </div>
                    </article>
                ))}
            </section>

            <section className="mt-6 rounded-3xl border border-slate-200 bg-white p-5 text-sm text-slate-600 shadow-sm">
                <h2 className="mb-2 text-sm font-semibold text-slate-900">
                    What you get:
                </h2>
                <ul className="list-disc space-y-1 pl-5 text-xs md:text-sm">
                    <li>One clear contact point for all questions before and during trip.</li>
                    <li>Transparent program with distances, times and difficulty level.</li>
                    <li>Support in Russian/English (and local contacts for drivers/guides).</li>
                </ul>
            </section>
        </div>
    );
}
