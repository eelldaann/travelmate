export default function ToursPage() {
    const tours = [
        {
            id: 1,
            title: "Almaty – Kolsai & Kaindy",
            days: "4 days",
            level: "Easy",
            price: "$620",
            desc: "Balanced route with alpine lakes, spruce forests and Charyn canyon.",
        },
        {
            id: 2,
            title: "Charyn Canyon & Altyn Emel dunes",
            days: "3 days",
            level: "Moderate",
            price: "$540",
            desc: "Canyons, singing dunes and steppe landscapes in one compact trip.",
        },
        {
            id: 3,
            title: "Mangystau & Bozzhyra cliffs",
            days: "5 days",
            level: "Intense",
            price: "$980",
            desc: "White cliffs, desert plateaus and surreal formations near the Caspian Sea.",
        },
    ];

    return (
        <div className="mx-auto max-w-6xl px-4 py-10 space-y-8">
            <header className="space-y-3">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-600">
                    Catalog
                </p>
                <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-slate-900">
                    Tours across Kazakhstan
                </h1>
                <p className="max-w-2xl text-sm md:text-base text-slate-600">
                    This is a visual list of sample itineraries. In your real app you can
                    load them from the backend, but layout will stay the same.
                </p>
            </header>

            <section className="grid gap-5 md:grid-cols-2">
                {tours.map((tour) => (
                    <article
                        key={tour.id}
                        className="flex flex-col justify-between rounded-3xl border border-slate-200 bg-white p-5 shadow-md"
                    >
                        <div className="space-y-2">
                            <h2 className="text-lg font-semibold text-slate-900">
                                {tour.title}
                            </h2>
                            <p className="text-sm text-slate-600">{tour.desc}</p>
                        </div>

                        <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-slate-500">
              <span className="rounded-full bg-slate-50 px-3 py-1 border border-slate-200">
                {tour.days}
              </span>
                            <span className="rounded-full bg-slate-50 px-3 py-1 border border-slate-200">
                Level: {tour.level}
              </span>
                            <span className="ml-auto text-sm font-semibold text-sky-600">
                {tour.price}
              </span>
                        </div>

                        <button
                            type="button"
                            className="mt-5 inline-flex items-center justify-center rounded-full bg-sky-500 px-4 py-2 text-xs font-medium uppercase tracking-[0.16em] text-white hover:bg-sky-400 transition"
                        >
                            Preview itinerary
                        </button>
                    </article>
                ))}
            </section>
        </div>
    );
}
