export default function HomePage() {
    return (
        <div className="mx-auto max-w-6xl px-4 py-10 space-y-12">
            <HeroSection />
            <DestinationsSection />
        </div>
    );
}

function HeroSection() {
    return (
        <section className="grid gap-10 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] items-center">
            {/* Левая часть */}
            <div className="space-y-6">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-600">
                    Kazakhstan tours
                </p>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-semibold tracking-tight text-slate-900">
                    Plan your next vacation across canyons, lakes and the Caspian coast.
                </h1>
                <p className="text-sm md:text-base text-slate-600 max-w-xl">
                    TravelMate helps you build a custom route across Kazakhstan: Burabay,
                    Charyn canyon, Bozzhyra, Caspian Sea and more. Pick your mood, budget
                    and dates — we’ll suggest ready-to-book itineraries.
                </p>

                {/* Планнер */}
                <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-5 shadow-lg">
                    <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-1.5">
                            <label className="block text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                                Mood
                            </label>
                            <div className="inline-flex rounded-full border border-slate-200 bg-slate-50 p-1 text-xs">
                                {["relax", "adventure", "culture"].map((mood) => (
                                    <button
                                        key={mood}
                                        type="button"
                                        className="flex-1 rounded-full px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.16em]
                               text-slate-700 data-[active=true]:bg-sky-500 data-[active=true]:text-white"
                                        data-active={mood === "relax"}
                                    >
                                        {mood}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="block text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                                Budget
                            </label>
                            <select className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-sky-500">
                                <option>Economy (hostels, trains)</option>
                                <option>Comfort (3–4★ hotels)</option>
                                <option>Premium (5★ &amp; private)</option>
                            </select>
                        </div>

                        <div className="space-y-1.5">
                            <label className="block text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                                Dates
                            </label>
                            <input
                                type="text"
                                placeholder="Anytime in 2025"
                                className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-sky-500"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label className="block text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                                Travelers
                            </label>
                            <input
                                type="number"
                                min={1}
                                defaultValue={2}
                                className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-sky-500"
                            />
                        </div>
                    </div>

                    <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <button className="inline-flex items-center justify-center rounded-full bg-sky-500 px-5 py-2 text-sm font-medium text-white hover:bg-sky-400 transition">
                            Build itinerary
                        </button>
                        <p className="text-[11px] text-slate-500">
                            We combine canyons, alpine lakes, dunes and heritage cities into
                            one balanced route.
                        </p>
                    </div>
                </div>
            </div>

            {/* Правая часть */}
            <div className="relative">
                <div className="relative aspect-[4/3] overflow-hidden rounded-3xl border border-slate-200 bg-slate-100 shadow-xl">
                    <img
                        src="/public/kolsai.jpg"
                        alt="Kolsai Lake in Kazakhstan"
                        className="h-full w-full object-cover"
                    />
                    <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />
                    <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-3 text-xs">
                        <div>
                            <p className="text-[10px] uppercase tracking-[0.2em] text-sky-100">
                                Signature route
                            </p>
                            <p className="mt-1 text-sm font-medium text-white">
                                Almaty → Kolsai → Charyn → Aktau
                            </p>
                        </div>
                        <div className="rounded-2xl bg-black/60 px-3 py-2 text-right backdrop-blur">
                            <p className="text-[10px] text-slate-100 uppercase tracking-[0.18em]">
                                from
                            </p>
                            <p className="text-sm font-semibold text-white">
                                $620 / person
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

function DestinationsSection() {
    const cards = [
        {
            img: "/public/charyn.jpg",
            title: "Charyn Canyon",
            tag: "Adventure • 2 days from Almaty",
            desc: "Mini-Grand Canyon of Kazakhstan with orange cliffs, sunset views and easy hiking.",
        },
        {
            img: "/public/kolsai.jpg",
            title: "Kolsai & Kaindy Lakes",
            tag: "Nature • 2–3 days",
            desc: "Glassy alpine lakes, spruce forests and the surreal flooded forest of Kaindy.",
        },
        {
            img: "/public/astana.jpg",
            title: "Astana & Nur-Sultan skyline",
            tag: "City • 1–2 days",
            desc: "Futuristic capital with modern architecture, museums and river promenades.",
        },
    ];

    return (
        <section className="space-y-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <h2 className="text-xl md:text-2xl font-semibold tracking-tight text-slate-900">
                        Signature destinations
                    </h2>
                    <p className="mt-1 text-sm text-slate-600">
                        All locations are in Kazakhstan. Photos are real places you can
                        visit with us.
                    </p>
                </div>
                <a
                    href="/tours"
                    className="inline-flex items-center rounded-full border border-slate-300 px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-slate-700 hover:border-sky-500 hover:text-sky-600 transition"
                >
                    See all tours
                </a>
            </div>

            <div className="grid gap-5 md:grid-cols-3">
                {cards.map((card) => (
                    <article
                        key={card.title}
                        className="group flex flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-md"
                    >
                        <div className="relative aspect-[4/3] overflow-hidden">
                            <img
                                src={card.img}
                                alt={card.title}
                                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                            />
                            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-transparent" />
                        </div>
                        <div className="flex flex-1 flex-col gap-2 p-4">
                            <h3 className="text-base font-semibold text-slate-900">
                                {card.title}
                            </h3>
                            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-sky-600">
                                {card.tag}
                            </p>
                            <p className="mt-1 text-sm text-slate-600">{card.desc}</p>
                        </div>
                    </article>
                ))}
            </div>
        </section>
    );
}
