import { Routes, Route, Link, Navigate } from "react-router";
import HomePage from "./pages/HomePage";
import ToursPage from "./pages/ToursPage";
import HowItWorksPage from "./pages/HowItWorksPage";
import AccountPage from "./pages/AccountPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

export default function App() {
    return (
        <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
            <Header />

            <main className="flex-1">
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/tours" element={<ToursPage />} />
                    <Route path="/how-it-works" element={<HowItWorksPage />} />
                    <Route path="/account" element={<AccountPage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />

                    {/* 404 */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </main>

            <Footer />
        </div>
    );
}

function Header() {
    return (
        <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:py-4">
                <Link
                    to="/"
                    className="flex items-center gap-2 text-lg md:text-xl font-semibold tracking-tight text-slate-900"
                >
          <span className="inline-flex size-8 items-center justify-center rounded-2xl bg-sky-500/10 border border-sky-500/40">
            <span className="text-sm font-bold text-sky-600">TM</span>
          </span>
                    <span>TravelMate</span>
                </Link>

                <nav className="hidden md:flex items-center gap-6 text-sm text-slate-600">
                    <NavItem to="/">Home</NavItem>
                    <NavItem to="/tours">Tours</NavItem>
                    <NavItem to="/how-it-works">How it works</NavItem>
                </nav>

                <div className="flex items-center gap-3 text-sm">
                    <Link
                        to="/login"
                        className="hidden sm:inline-flex items-center rounded-full border border-slate-300 px-4 py-1.5 text-slate-700 hover:border-sky-500 hover:text-sky-700 transition"
                    >
                        Log in
                    </Link>
                    <Link
                        to="/register"
                        className="inline-flex items-center rounded-full bg-sky-500 px-4 py-1.5 text-slate-50 font-medium hover:bg-sky-400 transition"
                    >
                        Sign up
                    </Link>
                </div>
            </div>
        </header>
    );
}

function NavItem({ to, children }) {
    return (
        <Link
            to={to}
            className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.16em] text-slate-600 hover:text-sky-600 transition"
        >
            {children}
        </Link>
    );
}

function Footer() {
    return (
        <footer className="border-top border-slate-200 mt-10 bg-white border-t">
            <div className="mx-auto max-w-6xl px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-slate-500">
                <span>© {new Date().getFullYear()} TravelMate — Kazakhstan Tours</span>
                <span className="flex gap-4">
          <a href="#" className="hover:text-sky-600 transition">
            Terms
          </a>
          <a href="#" className="hover:text-sky-600 transition">
            Privacy
          </a>
        </span>
            </div>
        </footer>
    );
}
